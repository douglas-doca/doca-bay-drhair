// utils/logger.ts — Fork do OCTA (idêntico)
// O migrate.sh vai copiar o original, este é fallback

import * as fs from 'fs';
import * as path from 'path';

export type LogLevel = 'debug' | 'info' | 'warn' | 'error';

export interface LogEntry {
  timestamp: string;
  level: LogLevel;
  message: string;
  data?: unknown;
  context?: string;
}

class Logger {
  private logLevel: LogLevel;
  private logDir: string;
  private logToFile: boolean;
  private logToConsole: boolean;

  private levelPriority: Record<LogLevel, number> = { debug: 0, info: 1, warn: 2, error: 3 };
  private levelColors: Record<LogLevel, string> = { debug: '\x1b[36m', info: '\x1b[32m', warn: '\x1b[33m', error: '\x1b[31m' };
  private levelEmojis: Record<LogLevel, string> = { debug: '🔍', info: '✅', warn: '⚠️', error: '❌' };

  constructor() {
    this.logLevel = (process.env.LOG_LEVEL as LogLevel) || 'info';
    this.logDir = process.env.LOG_DIR || './logs';
    this.logToFile = process.env.LOG_TO_FILE !== 'false';
    this.logToConsole = process.env.LOG_TO_CONSOLE !== 'false';
    if (this.logToFile && !fs.existsSync(this.logDir)) { fs.mkdirSync(this.logDir, { recursive: true }); }
  }

  private shouldLog(level: LogLevel): boolean { return this.levelPriority[level] >= this.levelPriority[this.logLevel]; }

  private log(level: LogLevel, message: string, data?: unknown, context?: string): void {
    if (!this.shouldLog(level)) return;
    const ts = new Date().toISOString();
    const entry: LogEntry = { timestamp: ts, level, message, data, context };
    if (this.logToConsole) {
      const reset = '\x1b[0m';
      const ctx = context ? `[${context}]` : '';
      let msg = `${this.levelColors[level]}${this.levelEmojis[level]} [${ts}] [${level.toUpperCase()}]${ctx} ${message}${reset}`;
      if (data) msg += `\n   ${JSON.stringify(data, null, 2)}`;
      console.error(msg);
    }
    if (this.logToFile) {
      try {
        const date = ts.split('T')[0];
        const line = JSON.stringify(entry) + '\n';
        fs.appendFileSync(path.join(this.logDir, `${level}-${date}.log`), line, 'utf8');
        fs.appendFileSync(path.join(this.logDir, `all-${date}.log`), line, 'utf8');
      } catch {}
    }
  }

  debug(message: string, data?: unknown, context?: string): void { this.log('debug', message, data, context); }
  info(message: string, data?: unknown, context?: string): void { this.log('info', message, data, context); }
  warn(message: string, data?: unknown, context?: string): void { this.log('warn', message, data, context); }
  error(message: string, data?: unknown, context?: string): void { this.log('error', message, data, context); }
  waha(message: string, data?: unknown): void { this.log('info', message, data, 'WAHA'); }
  ai(message: string, data?: unknown): void { this.log('info', message, data, 'AI'); }
  agent(message: string, data?: unknown): void { this.log('info', message, data, 'AGENT'); }
  webhook(message: string, data?: unknown): void { this.log('info', message, data, 'WEBHOOK'); }
  mcp(message: string, data?: unknown): void { this.log('info', message, data, 'MCP'); }
  conversation(message: string, data?: unknown): void { this.log('info', message, data, 'CONV'); }
  setLevel(level: LogLevel): void { this.logLevel = level; }
  getLevel(): LogLevel { return this.logLevel; }
  startTimer(label: string): () => void { const s = Date.now(); return () => this.debug(`${label}: ${Date.now() - s}ms`); }
  request(method: string, url: string, data?: unknown): void { this.debug(`→ ${method} ${url}`, data, 'HTTP'); }
  response(method: string, url: string, status: number, duration: number): void { this.log(status >= 400 ? 'error' : 'debug', `← ${method} ${url} [${status}] ${duration}ms`, undefined, 'HTTP'); }
  separator(title?: string): void {
    if (!this.logToConsole) return;
    const line = '═'.repeat(50);
    if (title) { console.error(`\n╔${line}╗\n║ ${title.padEnd(48)} ║\n╚${line}╝\n`); }
    else { console.error(`\n${'─'.repeat(52)}\n`); }
  }
}

export const logger = new Logger();
export { Logger };
