// types/index.ts — Tipos mínimos para o MCP Bay

export type ConversationStatus = "new" | "active" | "waiting_response" | "closed" | "open";
export type LeadStatus = "new" | "qualified" | "agendado" | "convertido" | "perdido";

export interface Lead {
  id: string;
  phone: string;
  name: string | null;
  email: string | null;
  source: string;
  score: number;
  status: LeadStatus;
  stage?: string | null;
  health_score?: number | null;
  urgency_level?: string | null;
  conversion_probability?: number | null;
  tags: string[];
  customFields: Record<string, any>;
  createdAt: Date;
  updatedAt: Date;
  tenant_id?: string;
}

export interface Message {
  id: string;
  role: "user" | "assistant" | "system";
  content: string;
  timestamp: Date;
  metadata: Record<string, any>;
}

export interface Conversation {
  id: string;
  chatId: string;
  phone: string;
  status: ConversationStatus;
  context: Record<string, any>;
  messages: Message[];
  createdAt: Date;
  updatedAt: Date;
  lastMessageAt: Date;
}

export interface AIConfig {
  provider?: string;
  apiKey?: string;
  model?: string;
  maxTokens?: number;
  temperature?: number;
}

export interface AIMessage {
  role: "user" | "assistant" | "system";
  content: string;
}

export interface AICompletionParams {
  messages: AIMessage[];
  systemPrompt?: string;
  maxTokens?: number;
  temperature?: number;
}

export interface AICompletionResponse {
  content: string;
  tokens: { prompt: number; completion: number; total: number };
  finishReason: string;
}
