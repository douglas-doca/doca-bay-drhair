// types/emotion.types.ts

export type EmotionType = "skeptical" | "anxious" | "frustrated" | "excited" | "price_sensitive" | "ready" | "curious" | "neutral";
export type LeadStage = "cético" | "frustrado" | "curioso" | "sensível_preço" | "empolgado" | "pronto";
export type UrgencyLevel = "low" | "normal" | "high" | "critical";

export interface EmotionEvent {
  id?: string;
  tenant_id: string;
  lead_id: string;
  conversation_id: string;
  emotion: string;
  confidence: number;
  source: string;
  message_content?: string;
  detected_at?: string;
}

export interface EmotionProfile {
  dominant_emotion: EmotionType;
  emotion_distribution: Record<string, number>;
  emotion_transitions: Array<{ from: string; to: string; count: number }>;
  last_updated: Date;
}

export interface HealthMetrics {
  health_score: number;
  temperature: number;
  conversion_probability: number;
  urgency_level: UrgencyLevel;
  friction_points: string[];
  positive_signals: string[];
}
