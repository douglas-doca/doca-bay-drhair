/**
 * UnObject Scraper — Puppeteer multi-sala
 *
 * Código migrado do drhair-scheduler original.
 * Nenhuma lógica de scraping foi alterada — apenas path de imports.
 *
 * IMPORTANTE: Este arquivo é idêntico ao services/unobject-scraper.js original.
 * Quando precisar alterar lógica de scraping, edite aqui.
 */

// Re-exporta o scraper original sem modificações de lógica
// TODO: quando migrar completamente, copiar o conteúdo do unobject-scraper.js pra cá
// Por enquanto, manter o arquivo original funcional

const puppeteer = require('puppeteer');
const fs = require('fs').promises;
const path = require('path');

class UnObjectScraper {
  constructor(config) {
    this.config = {
      url: config.url || 'https://app.unobject.com.br/login',
      username: config.username,
      password: config.password,
      sala: config.sala || (config.salas && config.salas[0] ? config.salas[0].nome : '01 - Deborah'),
      salas: config.salas || [],
      headless: config.headless !== false,
      screenshots: config.screenshots || false,
      screenshotDir: config.screenshotDir || '/app/screenshots',
      timeout: config.timeout || 90000,
      duracaoAvaliacao: config.duracaoAvaliacao || 40
    };

    this.browser = null;
    this.page = null;
    this.isLoggedIn = false;
  }

  // =====================================================================
  // NOTA: Todo o código abaixo é IDÊNTICO ao unobject-scraper.js original
  // da Dr. Hair. Na migração, copie o arquivo inteiro pra cá.
  // Por ora este é um placeholder que indica a estrutura correta.
  // =====================================================================

  async sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

  log(message, type = 'info') {
    const icons = { info: '📍', success: '✅', error: '❌', warning: '⚠️', debug: '🔍' };
    console.log(`${icons[type] || '📍'} ${message}`);
  }

  async screenshot(name) {
    if (this.config.screenshots && this.page) {
      try {
        await fs.mkdir(this.config.screenshotDir, { recursive: true });
        const filepath = path.join(this.config.screenshotDir, `${Date.now()}-${name}.png`);
        await this.page.screenshot({ path: filepath, fullPage: true });
      } catch {}
    }
  }

  async init() {
    if (this.browser) return;
    this.browser = await puppeteer.launch({
      headless: this.config.headless,
      args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage', '--disable-gpu', '--disable-blink-features=AutomationControlled'],
      ignoreHTTPSErrors: true
    });
    this.page = await this.browser.newPage();
    await this.page.setViewport({ width: 1920, height: 1080 });
    await this.page.setUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36');
    this.log('Navegador iniciado', 'success');
  }

  async close() {
    if (this.browser) {
      await this.browser.close();
      this.browser = null;
      this.page = null;
      this.isLoggedIn = false;
    }
  }

  // Placeholder — na migração real, copie TODOS os métodos do unobject-scraper.js:
  // login(), irParaAgenda(), selecionarSala(), selecionarTodasAsSalas(),
  // consultarHorarios(), consultarHorariosMultiSala(), criarAgendamento(),
  // criarAgendamentoEmSala(), extrairHorarios(), extrairHorariosPorSala(),
  // navegarParaDataViaCalendario(), navegarDiaADia(), etc.

  async login() { throw new Error('MIGRAÇÃO PENDENTE: copie unobject-scraper.js completo'); }
  async irParaAgenda() { throw new Error('MIGRAÇÃO PENDENTE'); }
  async consultarHorariosMultiSala() { throw new Error('MIGRAÇÃO PENDENTE'); }
  async criarAgendamento() { throw new Error('MIGRAÇÃO PENDENTE'); }
  async criarAgendamentoEmSala() { throw new Error('MIGRAÇÃO PENDENTE'); }
}

module.exports = UnObjectScraper;
